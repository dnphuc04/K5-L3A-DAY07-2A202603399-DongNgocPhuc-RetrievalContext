"""Real OpenAI or local embeddings; no silent fallback on provider failures."""
import hashlib
import json
import math
import urllib.error
import urllib.request
from pathlib import Path
from typing import Protocol


class Embedder(Protocol):
    model_name: str
    dimensions: int
    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...
    def embed_query(self, question: str) -> list[float]: ...


class OpenAIEmbedder:
    """Official REST endpoint using stdlib HTTP; batches, usage and disk cache."""
    def __init__(self, api_key: str, model_name: str = 'text-embedding-3-small',
                 dimensions: int = 1536, cache_dir: Path | None = None) -> None:
        if not api_key or not api_key.strip():
            raise ValueError('OPENAI_API_KEY is missing')
        if model_name != 'text-embedding-3-small' or not 1 <= dimensions <= 1536:
            raise ValueError('This adapter supports text-embedding-3-small, 1-1536 dimensions')
        self._api_key = api_key.strip()
        self.model_name, self.dimensions, self.cache_dir = model_name, dimensions, cache_dir
        self.prompt_tokens = self.api_requests = self.cache_hits = 0
        if cache_dir:
            cache_dir.mkdir(parents=True, exist_ok=True)

    def _validate_vector(self, vector):
        if (not isinstance(vector, list) or len(vector) != self.dimensions
                or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in vector)
                or not any(vector)):
            raise ValueError('Invalid embedding vector returned or cached')
        return vector

    def _request(self, texts):
        payload = json.dumps({'model': self.model_name, 'input': texts,
                              'dimensions': self.dimensions, 'encoding_format': 'float'}).encode('utf-8')
        request = urllib.request.Request('https://api.openai.com/v1/embeddings', data=payload,
                    headers={'Authorization': 'Bearer ' + self._api_key,
                             'Content-Type': 'application/json'}, method='POST')
        try:
            with urllib.request.urlopen(request, timeout=20) as response:
                body = json.load(response)
        except urllib.error.HTTPError as exc:
            # Never include request headers, credentials or raw provider error text.
            raise RuntimeError(f'OpenAI embeddings HTTP {exc.code}; check key, billing and model access') from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise RuntimeError('Cannot reach OpenAI embeddings endpoint; check network connectivity') from None
        rows = sorted(body.get('data', []), key=lambda row: row['index'])
        if [r['index'] for r in rows] != list(range(len(texts))):
            raise ValueError('OpenAI returned missing or duplicate embedding indices')
        vectors = [self._validate_vector(r['embedding']) for r in rows]
        self.prompt_tokens += int(body.get('usage', {}).get('prompt_tokens', 0))
        self.api_requests += 1
        return vectors

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if any(not text.strip() for text in texts):
            raise ValueError('Embedding inputs must be nonempty')
        # Corpus chunks are <=1000 characters; reject unexpected oversized input.
        if any(len(text.encode('utf-8')) > 8000 for text in texts):
            raise ValueError('Input exceeds this lab adapter safety bound; split it first')
        keys = [hashlib.sha256(json.dumps([self.model_name, self.dimensions, t], ensure_ascii=False).encode('utf-8')).hexdigest() for t in texts]
        resolved, missing = {}, {}
        for key, text in zip(keys, texts):
            path = self.cache_dir / f'{key}.json' if self.cache_dir else None
            if key in resolved:
                continue
            if path and path.exists():
                resolved[key] = self._validate_vector(json.loads(path.read_text(encoding='utf-8')))
                self.cache_hits += 1
            else:
                missing[key] = text
        pending = list(missing)
        for start in range(0, len(pending), 32):
            batch = pending[start:start + 32]
            vectors = self._request([missing[k] for k in batch])
            for key, vector in zip(batch, vectors):
                resolved[key] = vector
                if self.cache_dir:
                    path = self.cache_dir / f'{key}.json'
                    temp = path.with_suffix('.tmp')
                    temp.write_text(json.dumps(vector), encoding='utf-8')
                    temp.replace(path)
        return [resolved[key] for key in keys]

    def embed_query(self, question: str) -> list[float]:
        # OpenAI embeddings use the original text, without E5 query/passage prefixes.
        return self.embed_documents([question])[0]


class MyEmbedder:
    def __init__(self, model_name: str, revision: str | None = None) -> None:
        if model_name != 'intfloat/multilingual-e5-small':
            raise ValueError('This adapter implements the multilingual-e5-small input contract')
        from sentence_transformers import SentenceTransformer
        self.model_name, self.revision = model_name, revision
        self.model = SentenceTransformer(model_name, revision=revision, device='cpu')
        self.dimensions = self.model.get_sentence_embedding_dimension()
        if not self.dimensions:
            raise ValueError('Model did not report its embedding dimension')
        self.max_tokens = self.model.max_seq_length

    def _embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        for text in texts:
            length = len(self.model.tokenizer.encode(text, truncation=False))
            if length > self.max_tokens:
                raise ValueError(f'Input has {length} tokens, limit {self.max_tokens}; reduce chunk sizes before evaluation')
        return self.model.encode(texts, batch_size=16, normalize_embeddings=True,
                                 show_progress_bar=False).tolist()

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._embed(['passage: ' + text for text in texts])

    def embed_query(self, question: str) -> list[float]:
        return self._embed(['query: ' + question])[0]
